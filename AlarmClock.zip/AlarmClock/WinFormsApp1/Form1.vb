﻿Imports Microsoft.VisualBasic.Devices

Public Class AlarmClock
    Private activeTimePanel As TimePanel
    Private keypadButtons As Button()
    Private originalHeight As Integer
    Private customClockTime As DateTime = DateTime.Now
    Private customAlarmTime As DateTime = DateTime.Now


    'Set Time
    Private Sub SetLabel()
        Timer1.Interval = 1000
        Timer1.Start()
        If activeTimePanel Is TimePanelClock Then
            UpdateTimePanelClock()
        Else
            UpdateTimePanel()
        End If
    End Sub

    'Timer Tick
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        'lblClock.Text = DateTime.Now.ToString("hh:mm")
        customClockTime = customClockTime.AddSeconds(1)

        'UpdateTimePanelClock()
        'Only update the time panel if the set button is not pressed
        If TimePanelClock.SetClock.Enabled = False Then
        Else
            UpdateAMPMCheckbox()
            UpdateTimePanelClock()
        End If
        AlarmCheck()


    End Sub

    'AM/PM Checkbox
    Private Sub UpdateAMPMCheckbox()
        Dim currentHour As Integer = customClockTime.Hour
        If currentHour >= 12 AndAlso currentHour < 24 Then
            'PM
            TimePanelClock.PM.Checked = True
            TimePanelClock.AM.Checked = False
        Else
            'AM
            TimePanelClock.AM.Checked = True
            TimePanelClock.PM.Checked = False
        End If
    End Sub

    'Update Time Panel
    Private Sub UpdateTimePanelClock()

        Dim hours As Integer = customClockTime.Hour Mod 12
        If hours = 0 Then hours = 12 ' Handle 12-hour format

        TimePanelClock.Digitled0.DigitValue = hours \ 10 ' Tens place for hours
        TimePanelClock.Digitled1.DigitValue = hours Mod 10 ' Ones place for hours
        TimePanelClock.Digitled2.DigitValue = customClockTime.Minute \ 10 ' Tens place for minutes
        TimePanelClock.Digitled3.DigitValue = customClockTime.Minute Mod 10 ' Ones place for minutes
        TimePanelClock.AM.Checked = customClockTime.Hour < 12
        TimePanelClock.PM.Checked = customClockTime.Hour >= 12
    End Sub

    'Digit LED
    Private Sub UpdateTimePanel()
        If activeTimePanel Is Nothing OrElse activeTimePanel.Digitled0 Is Nothing Then
            ' Handle the case where activeTimePanel or Digitled0 is not initialized
            activeTimePanel = TimePanelClock
            Return
        End If
        Dim hours As Integer = customAlarmTime.Hour Mod 12
        If hours = 0 Then hours = 12 ' Handle 12-hour format

        activeTimePanel.Digitled0.DigitValue = hours \ 10 ' Tens place for hours
        activeTimePanel.Digitled1.DigitValue = hours Mod 10 ' Ones place for hours
        activeTimePanel.Digitled2.DigitValue = customAlarmTime.Minute \ 10 ' Tens place for minutes
        activeTimePanel.Digitled3.DigitValue = customAlarmTime.Minute Mod 10 ' Ones place for minutes
        activeTimePanel.AM.Checked = customAlarmTime.Hour < 12
        activeTimePanel.PM.Checked = customAlarmTime.Hour >= 12
    End Sub

    'am/pm change the time
    Private Sub UpdateTimePanel_AMPM(sender As Object, e As EventArgs)
        Dim currentHour As Integer = customClockTime.Hour
        If currentHour >= 12 AndAlso currentHour < 24 AndAlso TimePanelClock.AM.Checked = True Then
            'PM
            customClockTime = customClockTime.AddHours(-12)

        ElseIf currentHour < 12 AndAlso TimePanelClock.AM.Checked = True Then
            'AM
        ElseIf currentHour >= 12 AndAlso currentHour < 24 AndAlso TimePanelClock.PM.Checked = True Then
            'PM
        ElseIf currentHour < 12 AndAlso TimePanelClock.PM.Checked = True Then
            'AM
            customClockTime = customClockTime.AddHours(12)
        End If
    End Sub

    'picture setup
    Private Sub Picture()
        PictureBox1.Image = My.Resources.clock
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
        AlarmPanel1.PictureBoxAlarm.Image = My.Resources.gif11
        AlarmPanel2.PictureBoxAlarm.Image = My.Resources.gif21
        AlarmPanel2.PictureBoxAlarm.SizeMode = PictureBoxSizeMode.StretchImage
        AlarmPanel3.PictureBoxAlarm.Image = My.Resources.gif3
        AlarmPanel3.PictureBoxAlarm.SizeMode = PictureBoxSizeMode.StretchImage

    End Sub

    Private Sub AlarmClock_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Set the Ok button to black
        OKClock.BackColor = Color.Black
        Picture()
        SetLabel()
        'set button for clock
        AddHandler TimePanelClock.SetClock.Click, AddressOf ShowKeypadPanel
        'reset button for clock
        AddHandler TimePanelClock.ResetClock.Click, AddressOf ResetCLock1
        'clock pm/am change the time
        AddHandler TimePanelClock.AM.CheckedChanged, AddressOf UpdateTimePanel_AMPM
        'keypad
        keypadButtons = {Number1Clock, Number2Clock, Number3Clock, Number4Clock, Number5Clock, Number6Clock, Number7Clock, Number8Clock, Number9Clock, Number0Clock}
        For Each button In keypadButtons
            AddHandler button.Click, AddressOf KeypadButton_Click
        Next

        'Alarm ON Checkbox for Alarm1
        AddHandler AlarmPanel1.AlarmOn.CheckedChanged, AddressOf AlarmOn_CheckedChanged
        'set button for Alarm1
        AddHandler AlarmPanel1.TimePanel1.SetClock.Click, AddressOf ShowKeypadPanelAlarm1
        'reset button for Alarm1
        AddHandler AlarmPanel1.TimePanel1.ResetClock.Click, AddressOf ResetAlarm

        'Alarm ON Checkbox for Alarm2
        AddHandler AlarmPanel2.AlarmOn.CheckedChanged, AddressOf AlarmOn_CheckedChanged
        'set button for Alarm2
        AddHandler AlarmPanel2.TimePanel1.SetClock.Click, AddressOf ShowKeypadPanelAlarm2
        'reset button for Alarm2
        AddHandler AlarmPanel2.TimePanel1.ResetClock.Click, AddressOf ResetAlarm

        'Alarm ON Checkbox for Alarm3
        AddHandler AlarmPanel3.AlarmOn.CheckedChanged, AddressOf AlarmOn_CheckedChanged
        'set button for Alarm3
        AddHandler AlarmPanel3.TimePanel1.SetClock.Click, AddressOf ShowKeypadPanelAlarm3
        'reset button for Alarm3
        AddHandler AlarmPanel3.TimePanel1.ResetClock.Click, AddressOf ResetAlarm

    End Sub

    'Show Panel When the Set button Is pressed for Clock
    Public Sub ShowKeypadPanel()
        'Timer1.Stop()

        activeTimePanel = TimePanelClock ' Reference the active TimePanel (Clock or Alarm)

        customClockTime = TimePanelClock.Time
        panelKeypadClock.Visible = True
        ' Adjust form size to fit the keypad
        Me.Height += panelKeypadClock.Height
        UpdateKeypadButtons()
    End Sub

    'Show Panel When the Set button Is pressed for Alarm1
    Public Sub ShowKeypadPanelAlarm1()
        'Timer1.Stop()

        activeTimePanel = AlarmPanel1.TimePanel1 ' Reference the active TimePanel (Clock or Alarm)
        If activeTimePanel Is AlarmPanel1.TimePanel1 Then
            AlarmPanel1.previousAlarm = AlarmPanel1.TimePanel1.Time
        End If

        panelKeypadClock.Visible = True
        ' Adjust form size to fit the keypad
        Me.Height += panelKeypadClock.Height
        UpdateKeypadButtons()
    End Sub

    'Show Panel When the Set button Is pressed for Alarm2
    Public Sub ShowKeypadPanelAlarm2()
        'Timer1.Stop()

        activeTimePanel = AlarmPanel2.TimePanel1 ' Reference the active TimePanel (Clock or Alarm)
        If activeTimePanel Is AlarmPanel2.TimePanel1 Then
            AlarmPanel2.previousAlarm = AlarmPanel2.TimePanel1.Time
        End If

        panelKeypadClock.Visible = True
        ' Adjust form size to fit the keypad
        Me.Height += panelKeypadClock.Height
        UpdateKeypadButtons()
    End Sub

    'Show Panel When the Set button Is pressed for Alarm3
    Public Sub ShowKeypadPanelAlarm3()
        'Timer1.Stop()

        activeTimePanel = AlarmPanel3.TimePanel1 ' Reference the active TimePanel (Clock or Alarm)
        If activeTimePanel Is AlarmPanel3.TimePanel1 Then
            AlarmPanel3.previousAlarm = AlarmPanel3.TimePanel1.Time
        End If

        panelKeypadClock.Visible = True
        ' Adjust form size to fit the keypad
        Me.Height += panelKeypadClock.Height
        UpdateKeypadButtons()
    End Sub

    'Button reset Is pressed for clock
    Public Sub ResetCLock1(sender As Object, e As EventArgs)
        customClockTime = DateTime.Now
        SetLabel()
    End Sub

    'Button reset Is pressed for Alarm
    Public Sub ResetAlarm(sender As Object, e As EventArgs)
        customAlarmTime = New Date(Date.Now.Year, Date.Now.Month, Date.Now.Day, 0, 0, 0)
        If activeTimePanel IsNot TimePanelClock AndAlso Not Nothing Then
            'set the okey check button to false
            activeTimePanel.Ok_Click = False
            activeTimePanel.CancelInput()
        End If

    End Sub

    Public Sub HideKeypadPanel()
        panelKeypadClock.Visible = False
        Me.Height -= panelKeypadClock.Height
    End Sub

    'Keypad Button Click
    Private Sub KeypadButton_Click(sender As Object, e As EventArgs)
        Dim button As Button = DirectCast(sender, Button)
        Dim digit As Integer = Integer.Parse(button.Text)
        If activeTimePanel IsNot Nothing Then
            activeTimePanel.InputDigit(digit)
            UpdateKeypadButtons()
        End If
    End Sub

    ''Update Keypad Buttons
    Private Sub UpdateKeypadButtons()
        If activeTimePanel IsNot Nothing Then
            For Each button As Button In keypadButtons
                Dim digit As Integer = Integer.Parse(button.Text)
                button.Enabled = activeTimePanel.IsDigitValid(digit)
                'make button enabled more visible
                If button.Enabled Then
                    button.BackColor = Color.White
                Else
                    button.BackColor = Color.Black
                End If
            Next
        End If
    End Sub

    'OK Button press
    Private Sub OKClock_Click(sender As Object, e As EventArgs) Handles OKClock.Click
        If activeTimePanel Is TimePanelClock Then
            HideKeypadPanel()
            activeTimePanel.CancelOK_CLICK()
            Dim resultTime As Date
            If activeTimePanel.AMPM_Click() Then
            End If
            resultTime = New DateTime(customClockTime.Year, customClockTime.Month, customClockTime.Day, activeTimePanel.Digitled0.DigitValue * 10 + activeTimePanel.Digitled1.DigitValue, activeTimePanel.Digitled2.DigitValue * 10 + activeTimePanel.Digitled3.DigitValue, 0)
            If activeTimePanel.AMPM_Click() Then
                If resultTime.Hour < 12 Then
                    resultTime = resultTime.AddHours(12)
                End If
            Else
                If resultTime.Hour = 12 Then
                    resultTime = resultTime.AddHours(-12)
                End If
            End If
            customClockTime = resultTime
            'Timer1.Start()
        Else
            activeTimePanel.OK_Click_Set()
            HideKeypadPanel()
            activeTimePanel.CancelOK_CLICK()
            Dim resultTime As Date
            If activeTimePanel.AMPM_Click() Then
            End If
            resultTime = New DateTime(customClockTime.Year, customClockTime.Month, customClockTime.Day, activeTimePanel.Digitled0.DigitValue * 10 + activeTimePanel.Digitled1.DigitValue, activeTimePanel.Digitled2.DigitValue * 10 + activeTimePanel.Digitled3.DigitValue, 0)
            If activeTimePanel.AMPM_Click() Then
                If resultTime.Hour < 12 Then
                    resultTime = resultTime.AddHours(12)
                End If
            Else
                If resultTime.Hour = 12 Then
                    resultTime = resultTime.AddHours(-12)
                End If
            End If
            customAlarmTime = resultTime
            'Timer1.Start()
        End If


    End Sub


    'Cancel Button press
    Private Sub CancelClock_Click(sender As Object, e As EventArgs) Handles CancelClock.Click
        HideKeypadPanel()
        activeTimePanel.CancelInput()
        If activeTimePanel Is TimePanelClock Then
            SetLabel()
        ElseIf activeTimePanel Is AlarmPanel1.TimePanel1 Then
            If activeTimePanel.Ok_Click = False Then
                activeTimePanel.ResetStage()
            Else
                customAlarmTime = AlarmPanel1.previousAlarm
                SetLabel()
            End If


        ElseIf activeTimePanel Is AlarmPanel2.TimePanel1 Then
            If activeTimePanel.Ok_Click = False Then
                activeTimePanel.ResetStage()
            Else
                customAlarmTime = AlarmPanel2.previousAlarm
                SetLabel()
            End If

        ElseIf activeTimePanel Is AlarmPanel3.TimePanel1 Then
            If activeTimePanel.Ok_Click = False Then
                activeTimePanel.ResetStage()
            Else
                customAlarmTime = AlarmPanel3.previousAlarm
                SetLabel()
            End If

        End If


        activeTimePanel.CancelOK_CLICK()
    End Sub


    'link Alarm on Button
    Private Sub CheckBox3_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox3.CheckedChanged, CheckBox4.CheckedChanged, CheckBox5.CheckedChanged
        AlarmPanel1.AlarmOn.Checked = CheckBox3.Checked
        AlarmPanel2.AlarmOn.Checked = CheckBox4.Checked
        AlarmPanel3.AlarmOn.Checked = CheckBox5.Checked

    End Sub

    'AlarmOn_CheckedChanged
    Private Sub AlarmOn_CheckedChanged(sender As Object, e As EventArgs)
        CheckBox3.Checked = AlarmPanel1.AlarmOn.Checked
        CheckBox4.Checked = AlarmPanel2.AlarmOn.Checked
        CheckBox5.Checked = AlarmPanel3.AlarmOn.Checked
    End Sub

    'Alarm check
    Private Sub AlarmCheck()
        Dim currentClockTime As Date = New Date(customClockTime.Year, customClockTime.Month, customClockTime.Day, customClockTime.Hour, customClockTime.Minute, 0)
        Dim Alarm1Time As Date = New Date(customClockTime.Year, customClockTime.Month, customClockTime.Day, AlarmPanel1.TimePanel1.Digitled0.DigitValue * 10 + AlarmPanel1.TimePanel1.Digitled1.DigitValue, AlarmPanel1.TimePanel1.Digitled2.DigitValue * 10 + AlarmPanel1.TimePanel1.Digitled3.DigitValue, 0)
        Dim Alarm2Time As Date = New Date(customClockTime.Year, customClockTime.Month, customClockTime.Day, AlarmPanel2.TimePanel1.Digitled0.DigitValue * 10 + AlarmPanel2.TimePanel1.Digitled1.DigitValue, AlarmPanel2.TimePanel1.Digitled2.DigitValue * 10 + AlarmPanel2.TimePanel1.Digitled3.DigitValue, 0)
        Dim Alarm3Time As Date = New Date(customClockTime.Year, customClockTime.Month, customClockTime.Day, AlarmPanel3.TimePanel1.Digitled0.DigitValue * 10 + AlarmPanel3.TimePanel1.Digitled1.DigitValue, AlarmPanel3.TimePanel1.Digitled2.DigitValue * 10 + AlarmPanel3.TimePanel1.Digitled3.DigitValue, 0)
        Dim isAlarm1On As Boolean = AlarmPanel1.AlarmOn.Checked
        Dim isAlarm2On As Boolean = AlarmPanel2.AlarmOn.Checked
        Dim isAlarm3On As Boolean = AlarmPanel3.AlarmOn.Checked

        Dim isClockAM As Boolean = TimePanelClock.AM.Checked
        Dim isAlarm1AM As Boolean = AlarmPanel1.TimePanel1.AM.Checked
        Dim isAlarm2AM As Boolean = AlarmPanel2.TimePanel1.AM.Checked
        Dim isAlarm3AM As Boolean = AlarmPanel3.TimePanel1.AM.Checked
        If isAlarm1On AndAlso currentClockTime = Alarm1Time AndAlso isClockAM = isAlarm1AM Then
            AlarmPanel1.PlayAlarm()
            AlarmPanel1.PictureBoxAlarm.Visible = False
            CheckBox3.Checked = False
            AlarmPanel1.PictureAlarmButton.Visible = True
            AlarmPanel1.PictureAlarmButton.Image = My.Resources.gif1
        End If
        If isAlarm2On AndAlso currentClockTime = Alarm2Time AndAlso isClockAM = isAlarm2AM Then
            AlarmPanel2.PlayAlarm()
            AlarmPanel2.PictureBoxAlarm.Visible = False
            CheckBox4.Checked = False
            AlarmPanel2.PictureAlarmButton.Visible = True
            AlarmPanel2.PictureAlarmButton.Image = My.Resources.gif2
            'AlarmPanel2.PictureAlarmButton.AutoSizeMode = ImageLayout.Stretch
        End If
        If isAlarm3On AndAlso currentClockTime = Alarm3Time AndAlso isClockAM = isAlarm3AM Then
            AlarmPanel3.PlayAlarm()
            AlarmPanel3.PictureBoxAlarm.Visible = False
            CheckBox5.Checked = False
            AlarmPanel3.PictureAlarmButton.Visible = True
            AlarmPanel3.PictureAlarmButton.Image = My.Resources.gif31
            'AlarmPanel3.PictureAlarmButton.AutoSizeMode = ImageLayout.Stretch
        End If
    End Sub

End Class
