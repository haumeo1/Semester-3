﻿Public Class TimePanel
    Private digits As DigitLED()
    Private currentDigitIndex As Integer
    Public Time As Date = New Date(Date.Now.Year, Date.Now.Month, Date.Now.Day, 0, 0, 0)
    'Variable to check whether it's the second time the user is pressing the OK button
    Public Ok_Click As Boolean = False
    'Public TimePanel As String
    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        digits = {Digitled0, Digitled1, Digitled2, Digitled3}
        currentDigitIndex = 0
    End Sub
    Public Sub InputDigit(digit As Integer)


        If currentDigitIndex < digits.Length Then
            Dim digitLED As DigitLED = digits(currentDigitIndex)
            If digit <= digitLED.MaxDigitValue() Then
                digitLED.DigitValue = digit
                digits(currentDigitIndex).ForeColor = Color.Red
                'TimePanel = TimePanel & digit.ToString()
                currentDigitIndex += 1 ' Move to the next digit
            End If
        End If
    End Sub

    'Check if the digit is valid
    Public Function IsDigitValid(digit As Integer) As Boolean
        If currentDigitIndex = 0 Then
            digits(currentDigitIndex).MaxDigitValue = 1
            digits(currentDigitIndex).ForeColor = Color.Yellow
        ElseIf currentDigitIndex = 1 AndAlso digits(currentDigitIndex - 1).DigitValue() = 1 Then
            digits(currentDigitIndex).MaxDigitValue = 2
            digits(currentDigitIndex).ForeColor = Color.Yellow
        ElseIf currentDigitIndex = 1 Then
            digits(currentDigitIndex).MaxDigitValue = 9
            digits(currentDigitIndex).ForeColor = Color.Yellow
        ElseIf currentDigitIndex = 2 Then
            digits(currentDigitIndex).MaxDigitValue = 5
            digits(currentDigitIndex).ForeColor = Color.Yellow
        ElseIf currentDigitIndex = 3 Then
            digits(currentDigitIndex).MaxDigitValue = 9
            digits(currentDigitIndex).ForeColor = Color.Yellow
            'If currentDigitIndex = 3 enable the OK button
        ElseIf currentDigitIndex = 4 Then
            Dim parentForm As AlarmClock = TryCast(Me.ParentForm, AlarmClock)
                parentForm.OKClock.Enabled = True
            parentForm.OKClock.BackColor = Color.White
        End If

        If currentDigitIndex < digits.Length Then
            Dim maxDigit As Integer = digits(currentDigitIndex).MaxDigitValue()
            ''If currentDigitIndex = 3 enable the OK button
            'If currentDigitIndex = 3 AndAlso digit <= maxDigit Then
            '    Dim parentForm As AlarmClock = TryCast(Me.ParentForm, AlarmClock)
            '    parentForm.OKClock.Enabled = True
            '    parentForm.OKClock.BackColor = Color.White
            '    Return True
            'End If

            Return digit <= maxDigit
        End If
        Return False
    End Function

    Public Sub CancelInput()
        For Each digitLED As DigitLED In digits
            digitLED.DigitValue = 0 ' Reset each digit to 0
            'double check the color
            digitLED.ForeColor = Color.Red
        Next
    End Sub

    'Set the first stage
    Private Sub SetClock_Click(sender As Object, e As EventArgs) Handles SetClock.Click
        Time = TimePanelValue()
        Digitled0.DigitValue = 0
        Digitled1.DigitValue = 0
        Digitled2.DigitValue = 0
        Digitled3.DigitValue = 0
        SetClock.Enabled = False
        ResetClock.Enabled = False

    End Sub

    'Reset the STAGE
    Public Sub ResetStage()
        Digitled0.DigitValue = 0
        Digitled1.DigitValue = 0
        Digitled2.DigitValue = 0
        Digitled3.DigitValue = 0
    End Sub

    Private Sub ResetClock_Click(sender As Object, e As EventArgs) Handles ResetClock.Click
        CancelInput()
    End Sub

    Public Sub CancelOK_CLICK()
        'double check the color
        For Each digitLED As DigitLED In digits
            digitLED.ForeColor = Color.Red
        Next
        SetClock.Enabled = True
        ResetClock.Enabled = True
        currentDigitIndex = 0
    End Sub

    'Check whether it the second time The OK button is clicked

    'Return true if AM is checked, false if PM is checked
    Public Function AMPM_Click() As Boolean
        If AM.Checked = True Then
            Return False
        Else
            Return True
        End If
    End Function
    Private Sub Time_Panel(sender As Object, e As EventArgs) Handles MyBase.Load
        AM.Checked = True
    End Sub

    'get and set method for the time panel
    Public Property TimePanelValue() As String
        Get
            Dim TimeString As String = String.Format("{0}{1}:{2}{3}", digits(0).DigitValue, digits(1).DigitValue, digits(2).DigitValue, digits(3).DigitValue)
            Date.TryParseExact(TimeString, "HH:mm", Nothing, Globalization.DateTimeStyles.None, Time)
            Return Time
        End Get
        Set(ByVal value As String)
            'Dim TimeString As String = value.ToString("hhmm")
            'Dim TimeArray As Char() = TimeString.ToCharArray()
            'For i As Integer = 0 To TimeArray.Length - 1
            '    digits(i).DigitValue = Integer.Parse(TimeArray(i))
            'Next
        End Set
    End Property

    'Set the OK button to true
    Public Sub OK_Click_Set()
        Ok_Click = True
    End Sub

End Class
