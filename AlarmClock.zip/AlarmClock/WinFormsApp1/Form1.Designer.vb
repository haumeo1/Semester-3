﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class AlarmClock
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        components = New ComponentModel.Container()
        TabControl1 = New TabControl()
        TabPage2 = New TabPage()
        PictureBox1 = New PictureBox()
        CheckBox5 = New CheckBox()
        CheckBox4 = New CheckBox()
        CheckBox3 = New CheckBox()
        TimePanelClock = New TimePanel()
        TabPage3 = New TabPage()
        AlarmPanel1 = New AlarmPanel()
        TabPage4 = New TabPage()
        AlarmPanel2 = New AlarmPanel()
        TabPage1 = New TabPage()
        AlarmPanel3 = New AlarmPanel()
        panelKeypadClock = New Panel()
        OKClock = New Button()
        Number9Clock = New Button()
        Number6Clock = New Button()
        Number3Clock = New Button()
        Number0Clock = New Button()
        Number8Clock = New Button()
        Number5Clock = New Button()
        Number2Clock = New Button()
        CancelClock = New Button()
        Number7Clock = New Button()
        Number4Clock = New Button()
        Number1Clock = New Button()
        Timer1 = New Timer(components)
        TabControl1.SuspendLayout()
        TabPage2.SuspendLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        TabPage3.SuspendLayout()
        TabPage4.SuspendLayout()
        TabPage1.SuspendLayout()
        panelKeypadClock.SuspendLayout()
        SuspendLayout()
        ' 
        ' TabControl1
        ' 
        TabControl1.Controls.Add(TabPage2)
        TabControl1.Controls.Add(TabPage3)
        TabControl1.Controls.Add(TabPage4)
        TabControl1.Controls.Add(TabPage1)
        TabControl1.Location = New Point(-2, 1)
        TabControl1.Name = "TabControl1"
        TabControl1.SelectedIndex = 0
        TabControl1.Size = New Size(692, 244)
        TabControl1.TabIndex = 0
        ' 
        ' TabPage2
        ' 
        TabPage2.BackColor = Color.Black
        TabPage2.Controls.Add(PictureBox1)
        TabPage2.Controls.Add(CheckBox5)
        TabPage2.Controls.Add(CheckBox4)
        TabPage2.Controls.Add(CheckBox3)
        TabPage2.Controls.Add(TimePanelClock)
        TabPage2.ForeColor = Color.Red
        TabPage2.Location = New Point(4, 24)
        TabPage2.Name = "TabPage2"
        TabPage2.Padding = New Padding(3)
        TabPage2.Size = New Size(684, 216)
        TabPage2.TabIndex = 1
        TabPage2.Text = "Clock"
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Location = New Point(466, 19)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(208, 137)
        PictureBox1.TabIndex = 9
        PictureBox1.TabStop = False
        ' 
        ' CheckBox5
        ' 
        CheckBox5.AutoSize = True
        CheckBox5.ForeColor = Color.Red
        CheckBox5.Location = New Point(485, 183)
        CheckBox5.Name = "CheckBox5"
        CheckBox5.Size = New Size(67, 19)
        CheckBox5.TabIndex = 8
        CheckBox5.Text = "Alarm 3"
        CheckBox5.TextAlign = ContentAlignment.MiddleCenter
        CheckBox5.UseVisualStyleBackColor = True
        ' 
        ' CheckBox4
        ' 
        CheckBox4.AutoSize = True
        CheckBox4.ForeColor = Color.Red
        CheckBox4.Location = New Point(299, 183)
        CheckBox4.Name = "CheckBox4"
        CheckBox4.Size = New Size(67, 19)
        CheckBox4.TabIndex = 7
        CheckBox4.Text = "Alarm 2"
        CheckBox4.TextAlign = ContentAlignment.MiddleCenter
        CheckBox4.UseVisualStyleBackColor = True
        ' 
        ' CheckBox3
        ' 
        CheckBox3.AutoSize = True
        CheckBox3.ForeColor = Color.Red
        CheckBox3.Location = New Point(111, 183)
        CheckBox3.Name = "CheckBox3"
        CheckBox3.Size = New Size(67, 19)
        CheckBox3.TabIndex = 6
        CheckBox3.Text = "Alarm 1"
        CheckBox3.TextAlign = ContentAlignment.MiddleCenter
        CheckBox3.UseVisualStyleBackColor = True
        ' 
        ' TimePanelClock
        ' 
        TimePanelClock.BackColor = SystemColors.ControlText
        TimePanelClock.Location = New Point(0, 0)
        TimePanelClock.Name = "TimePanelClock"
        TimePanelClock.Size = New Size(475, 177)
        TimePanelClock.TabIndex = 0
        TimePanelClock.TimePanelValue = "10/14/2024"
        ' 
        ' TabPage3
        ' 
        TabPage3.Controls.Add(AlarmPanel1)
        TabPage3.Location = New Point(4, 24)
        TabPage3.Name = "TabPage3"
        TabPage3.Padding = New Padding(3)
        TabPage3.Size = New Size(684, 216)
        TabPage3.TabIndex = 2
        TabPage3.Text = "Alarm1"
        TabPage3.UseVisualStyleBackColor = True
        ' 
        ' AlarmPanel1
        ' 
        AlarmPanel1.BackColor = Color.Black
        AlarmPanel1.Location = New Point(0, 0)
        AlarmPanel1.Name = "AlarmPanel1"
        AlarmPanel1.Size = New Size(684, 216)
        AlarmPanel1.TabIndex = 0
        ' 
        ' TabPage4
        ' 
        TabPage4.Controls.Add(AlarmPanel2)
        TabPage4.Location = New Point(4, 24)
        TabPage4.Name = "TabPage4"
        TabPage4.Padding = New Padding(3)
        TabPage4.Size = New Size(684, 216)
        TabPage4.TabIndex = 3
        TabPage4.Text = "Alarm2"
        TabPage4.UseVisualStyleBackColor = True
        ' 
        ' AlarmPanel2
        ' 
        AlarmPanel2.BackColor = Color.Black
        AlarmPanel2.Location = New Point(0, 0)
        AlarmPanel2.Name = "AlarmPanel2"
        AlarmPanel2.Size = New Size(684, 216)
        AlarmPanel2.TabIndex = 0
        ' 
        ' TabPage1
        ' 
        TabPage1.Controls.Add(AlarmPanel3)
        TabPage1.Location = New Point(4, 24)
        TabPage1.Name = "TabPage1"
        TabPage1.Padding = New Padding(3)
        TabPage1.Size = New Size(684, 216)
        TabPage1.TabIndex = 4
        TabPage1.Text = "Alarm3"
        TabPage1.UseVisualStyleBackColor = True
        ' 
        ' AlarmPanel3
        ' 
        AlarmPanel3.BackColor = Color.Black
        AlarmPanel3.ForeColor = SystemColors.ControlText
        AlarmPanel3.Location = New Point(0, 0)
        AlarmPanel3.Name = "AlarmPanel3"
        AlarmPanel3.Size = New Size(684, 216)
        AlarmPanel3.TabIndex = 0
        ' 
        ' panelKeypadClock
        ' 
        panelKeypadClock.Controls.Add(OKClock)
        panelKeypadClock.Controls.Add(Number9Clock)
        panelKeypadClock.Controls.Add(Number6Clock)
        panelKeypadClock.Controls.Add(Number3Clock)
        panelKeypadClock.Controls.Add(Number0Clock)
        panelKeypadClock.Controls.Add(Number8Clock)
        panelKeypadClock.Controls.Add(Number5Clock)
        panelKeypadClock.Controls.Add(Number2Clock)
        panelKeypadClock.Controls.Add(CancelClock)
        panelKeypadClock.Controls.Add(Number7Clock)
        panelKeypadClock.Controls.Add(Number4Clock)
        panelKeypadClock.Controls.Add(Number1Clock)
        panelKeypadClock.Location = New Point(100, 251)
        panelKeypadClock.Name = "panelKeypadClock"
        panelKeypadClock.Size = New Size(478, 348)
        panelKeypadClock.TabIndex = 18
        panelKeypadClock.Visible = False
        ' 
        ' OKClock
        ' 
        OKClock.Enabled = False
        OKClock.Location = New Point(321, 262)
        OKClock.Name = "OKClock"
        OKClock.Size = New Size(153, 75)
        OKClock.TabIndex = 11
        OKClock.Text = "OK"
        OKClock.UseVisualStyleBackColor = True
        ' 
        ' Number9Clock
        ' 
        Number9Clock.Location = New Point(321, 181)
        Number9Clock.Name = "Number9Clock"
        Number9Clock.Size = New Size(153, 75)
        Number9Clock.TabIndex = 10
        Number9Clock.Text = "9"
        Number9Clock.UseVisualStyleBackColor = True
        ' 
        ' Number6Clock
        ' 
        Number6Clock.Location = New Point(321, 100)
        Number6Clock.Name = "Number6Clock"
        Number6Clock.Size = New Size(153, 75)
        Number6Clock.TabIndex = 9
        Number6Clock.Text = "6"
        Number6Clock.UseVisualStyleBackColor = True
        ' 
        ' Number3Clock
        ' 
        Number3Clock.Location = New Point(321, 19)
        Number3Clock.Name = "Number3Clock"
        Number3Clock.Size = New Size(153, 75)
        Number3Clock.TabIndex = 8
        Number3Clock.Text = "3"
        Number3Clock.UseVisualStyleBackColor = True
        ' 
        ' Number0Clock
        ' 
        Number0Clock.Location = New Point(162, 262)
        Number0Clock.Name = "Number0Clock"
        Number0Clock.Size = New Size(153, 75)
        Number0Clock.TabIndex = 7
        Number0Clock.Text = "0"
        Number0Clock.UseVisualStyleBackColor = True
        ' 
        ' Number8Clock
        ' 
        Number8Clock.Location = New Point(162, 181)
        Number8Clock.Name = "Number8Clock"
        Number8Clock.Size = New Size(153, 75)
        Number8Clock.TabIndex = 6
        Number8Clock.Text = "8"
        Number8Clock.UseVisualStyleBackColor = True
        ' 
        ' Number5Clock
        ' 
        Number5Clock.Location = New Point(162, 100)
        Number5Clock.Name = "Number5Clock"
        Number5Clock.Size = New Size(153, 75)
        Number5Clock.TabIndex = 5
        Number5Clock.Text = "5"
        Number5Clock.UseVisualStyleBackColor = True
        ' 
        ' Number2Clock
        ' 
        Number2Clock.Location = New Point(162, 19)
        Number2Clock.Name = "Number2Clock"
        Number2Clock.Size = New Size(153, 75)
        Number2Clock.TabIndex = 4
        Number2Clock.Text = "2"
        Number2Clock.UseVisualStyleBackColor = True
        ' 
        ' CancelClock
        ' 
        CancelClock.Location = New Point(3, 262)
        CancelClock.Name = "CancelClock"
        CancelClock.Size = New Size(153, 75)
        CancelClock.TabIndex = 3
        CancelClock.Text = "Cancel"
        CancelClock.UseVisualStyleBackColor = True
        ' 
        ' Number7Clock
        ' 
        Number7Clock.Location = New Point(3, 181)
        Number7Clock.Name = "Number7Clock"
        Number7Clock.Size = New Size(153, 75)
        Number7Clock.TabIndex = 2
        Number7Clock.Text = "7"
        Number7Clock.UseVisualStyleBackColor = True
        ' 
        ' Number4Clock
        ' 
        Number4Clock.Location = New Point(3, 100)
        Number4Clock.Name = "Number4Clock"
        Number4Clock.Size = New Size(153, 75)
        Number4Clock.TabIndex = 1
        Number4Clock.Text = "4"
        Number4Clock.UseVisualStyleBackColor = True
        ' 
        ' Number1Clock
        ' 
        Number1Clock.Location = New Point(3, 19)
        Number1Clock.Name = "Number1Clock"
        Number1Clock.Size = New Size(153, 75)
        Number1Clock.TabIndex = 0
        Number1Clock.Text = "1"
        Number1Clock.UseVisualStyleBackColor = True
        ' 
        ' Timer1
        ' 
        ' 
        ' AlarmClock
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.DimGray
        ClientSize = New Size(688, 243)
        Controls.Add(panelKeypadClock)
        Controls.Add(TabControl1)
        Name = "AlarmClock"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Benjamin To' Alarm Clock"
        TabControl1.ResumeLayout(False)
        TabPage2.ResumeLayout(False)
        TabPage2.PerformLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        TabPage3.ResumeLayout(False)
        TabPage4.ResumeLayout(False)
        TabPage1.ResumeLayout(False)
        panelKeypadClock.ResumeLayout(False)
        ResumeLayout(False)
    End Sub

    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents TabPage4 As TabPage
    Friend WithEvents panelKeypadClock As Panel
    Friend WithEvents OKClock As Button
    Friend WithEvents Number9Clock As Button
    Friend WithEvents Number6Clock As Button
    Friend WithEvents Number3Clock As Button
    Friend WithEvents Number0Clock As Button
    Friend WithEvents Number8Clock As Button
    Friend WithEvents Number5Clock As Button
    Friend WithEvents Number2Clock As Button
    Friend WithEvents CancelClock As Button
    Friend WithEvents Number7Clock As Button
    Friend WithEvents Number4Clock As Button
    Friend WithEvents Number1Clock As Button
    Friend WithEvents TimePanelClock As TimePanel
    Friend WithEvents Timer1 As Timer
    Friend WithEvents CheckBox5 As CheckBox
    Friend WithEvents CheckBox4 As CheckBox
    Friend WithEvents CheckBox3 As CheckBox
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents AlarmPanel1 As AlarmPanel
    Friend WithEvents AlarmPanel2 As AlarmPanel
    Friend WithEvents AlarmPanel3 As AlarmPanel

End Class
