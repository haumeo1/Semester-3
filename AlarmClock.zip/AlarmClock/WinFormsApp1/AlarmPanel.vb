﻿Imports System.ComponentModel.Design
Imports System.Linq.Expressions
Imports System.Media

Public Class AlarmPanel
    'previousr Alarm fisrt set to all zero
    Public previousAlarm As Date = New Date(Date.Now.Year, Date.Now.Month, Date.Now.Day, 0, 0, 0)
    Private soundPlayer As SoundPlayer
    Private soundPath As String = ""
    Private Sub Alarm_Set()
        Dim temp As Date
        temp = New DateTime(Date.Now.Year, Date.Now.Month, Date.Now.Day, TimePanel1.Digitled0.DigitValue * 10 + TimePanel1.Digitled1.DigitValue, TimePanel1.Digitled2.DigitValue * 10 + TimePanel1.Digitled3.DigitValue, 0)
        If TimePanel1.AMPM_Click() Then
            If previousAlarm.Hour < 12 Then
                previousAlarm = previousAlarm.AddHours(12)
            End If
        Else
            If previousAlarm.Hour = 12 Then
                previousAlarm = previousAlarm.AddHours(-12)
            End If
        End If
    End Sub

    Private Sub AlarmClock_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        'SetLabel(lblClock)
        Alarm_Set()
        cmbSoundSelection.Items.Add("Sound 1 - Default")
        cmbSoundSelection.Items.Add("Sound 2 - Retro")
        cmbSoundSelection.Items.Add("Sound 3 - Vintage")
        cmbSoundSelection.Items.Add("Sound 4 - Slot Machine")
        cmbSoundSelection.Items.Add("Sound 5 - Spaceship")
        cmbSoundSelection.SelectedIndex = 0
        'Update the time whenever the am/pm is changed
        AddHandler TimePanel1.ResetClock.Click, AddressOf Reset_TurnOf
    End Sub

    'Turn Of Alarm when press reset
    Private Sub Reset_TurnOf(sender As Object, e As EventArgs)
        AlarmOn.Checked = False
    End Sub

    Public Sub StopAlarmSound()
        If soundPlayer IsNot Nothing Then
            soundPlayer.Stop() ' Stop 
            soundPath = "" 'path
        End If
    End Sub

    'Set sound Path
    Public Sub PlayAlarm()
        Select Case cmbSoundSelection.SelectedIndex
            Case 0
                soundPath = "SoundFile\classic.wav"
            Case 1
                soundPath = "SoundFile\retro-game.wav"
            Case 2
                soundPath = "SoundFile\slotmachine.wav"
            Case 3
                soundPath = "SoundFile\spaceship.wav"
            Case 4
                soundPath = "SoundFile\vintage.wav"

        End Select
        soundPlayer = New SoundPlayer(soundPath)
        soundPlayer.Play()
        soundPlayer.Play()
    End Sub

    'take in a picture from resouces

    Public Sub Picture(imageName As Image)
        Dim myImage As Image
        myImage = imageName
        PictureBoxAlarm.Image = myImage
    End Sub

    Private Sub PictureAlarmButton_Click(sender As Object, e As EventArgs) Handles PictureAlarmButton.Click
        StopAlarmSound()
        PictureBoxAlarm.Visible = True
        PictureAlarmButton.Visible = False
    End Sub
End Class
