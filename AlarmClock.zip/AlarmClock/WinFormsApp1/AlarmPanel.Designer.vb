﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AlarmPanel
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        PictureBoxAlarm = New PictureBox()
        AlarmOn = New CheckBox()
        cmbSoundSelection = New ComboBox()
        PictureAlarmButton = New Button()
        TimePanel1 = New TimePanel()
        CType(PictureBoxAlarm, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' PictureBoxAlarm
        ' 
        PictureBoxAlarm.Location = New Point(465, 19)
        PictureBoxAlarm.Name = "PictureBoxAlarm"
        PictureBoxAlarm.Size = New Size(208, 137)
        PictureBoxAlarm.TabIndex = 37
        PictureBoxAlarm.TabStop = False
        ' 
        ' AlarmOn
        ' 
        AlarmOn.AutoSize = True
        AlarmOn.ForeColor = Color.Red
        AlarmOn.Location = New Point(113, 179)
        AlarmOn.Name = "AlarmOn"
        AlarmOn.Size = New Size(77, 19)
        AlarmOn.TabIndex = 32
        AlarmOn.Text = "Alarm On"
        AlarmOn.TextAlign = ContentAlignment.MiddleCenter
        AlarmOn.UseVisualStyleBackColor = True
        ' 
        ' cmbSoundSelection
        ' 
        cmbSoundSelection.FormattingEnabled = True
        cmbSoundSelection.Location = New Point(500, 177)
        cmbSoundSelection.Name = "cmbSoundSelection"
        cmbSoundSelection.Size = New Size(136, 23)
        cmbSoundSelection.TabIndex = 35
        ' 
        ' PictureAlarmButton
        ' 
        PictureAlarmButton.Location = New Point(465, 19)
        PictureAlarmButton.Name = "PictureAlarmButton"
        PictureAlarmButton.Size = New Size(208, 137)
        PictureAlarmButton.TabIndex = 36
        PictureAlarmButton.UseVisualStyleBackColor = True
        PictureAlarmButton.Visible = False
        ' 
        ' TimePanel1
        ' 
        TimePanel1.BackColor = Color.Black
        TimePanel1.Location = New Point(0, 0)
        TimePanel1.Name = "TimePanel1"
        TimePanel1.Size = New Size(459, 177)
        TimePanel1.TabIndex = 38
        TimePanel1.TimePanelValue = "10/12/2024"
        ' 
        ' AlarmPanel
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = SystemColors.ControlText
        Controls.Add(TimePanel1)
        Controls.Add(PictureBoxAlarm)
        Controls.Add(PictureAlarmButton)
        Controls.Add(cmbSoundSelection)
        Controls.Add(AlarmOn)
        Name = "AlarmPanel"
        Size = New Size(684, 216)
        CType(PictureBoxAlarm, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents PictureBoxAlarm As PictureBox
    Friend WithEvents AlarmOn As CheckBox
    Friend WithEvents cmbSoundSelection As ComboBox
    Friend WithEvents PictureAlarmButton As Button
    Friend WithEvents TimePanel1 As TimePanel

End Class
